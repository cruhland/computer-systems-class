
#include "string.h"
#include <stdio.h>

int main() {
    /* Test out your string here */

    return 0;
}
